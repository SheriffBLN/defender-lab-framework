# Detection notes for T1136.001 (Create Account: Local Account)

TODO