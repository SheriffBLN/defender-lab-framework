# Simulates creation of a local user account
net user testuser Pass123! /add
