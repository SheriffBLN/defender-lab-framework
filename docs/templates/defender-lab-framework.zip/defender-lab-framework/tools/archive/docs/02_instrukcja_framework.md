## 📘 Pełna instrukcja działania frameworka

- alerts/ – pliki źródłowe (.md)
- scenarios/ – wynikowe scenariusze
- mapping/ – warstwy i status.csv
- report/ – raport HTML + tabela MITRE

Każdy krok obsługiwany jest przez skrypty w `tools/`.