## 🏁 Szybki Start

1. Uruchom `001_generate_by_tid.py`, by stworzyć scenariusz `.md`
2. Odpal `merge_all_full.py`, by wygenerować statusy, raporty i warstwy
3. Wejdź do `report/index.html`, by zobaczyć efekty 🔍