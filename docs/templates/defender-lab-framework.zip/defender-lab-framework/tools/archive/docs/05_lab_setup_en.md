## 🔧 Lab Setup (EN)

1. Windows 11 endpoint with MDE P2
2. Enabled logging: PowerShell, Task Scheduler
3. Local clone of this repo
4. PowerShell execution policy: Bypass