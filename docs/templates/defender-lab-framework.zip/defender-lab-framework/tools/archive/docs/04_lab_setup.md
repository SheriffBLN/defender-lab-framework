## 🔧 Konfiguracja labu (PL)

1. Maszyna z Windows 11 + Defender for Endpoint (P2)
2. Włączone logowanie PowerShell, TaskScheduler
3. Repo sklonowane lokalnie
4. PowerShell w trybie Bypass