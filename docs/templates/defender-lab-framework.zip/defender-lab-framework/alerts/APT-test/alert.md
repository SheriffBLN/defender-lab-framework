# Alert: Execution Guardrails

#SCENARIO
Tutaj wpisz opis scenariusza. Możesz używać wielu linii.
#ENDSCENARIO

---

**Technika:** T1480  
**Nazwa:** Execution Guardrails  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1480
Technique Name: Execution Guardrails
Status: Pending
--> 
