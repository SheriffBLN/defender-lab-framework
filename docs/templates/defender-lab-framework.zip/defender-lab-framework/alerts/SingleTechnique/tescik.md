# Alert: Local Accounts

#SCENARIO
Tutaj wpisz opis scenariusza. Możesz używać wielu linii.
#ENDSCENARIO

---

**Technika:** T1078.003  
**Nazwa:** Local Accounts  
**Taktyki:** Defense-Evasion, Initial-Access, Persistence, Privilege-Escalation  
**Status:** Tested  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion, Initial-Access, Persistence, Privilege-Escalation
Technique ID: T1078.003
Technique Name: Local Accounts
Status: Tested
--> 
