# Alert: PowerShell

#SCENARIO
Tutaj wpisz opis scenariusza. Możesz używać wielu linii.
#ENDSCENARIO

---

**Technika:** T1059.001  
**Nazwa:** PowerShell  
**Taktyki:** Execution  
**Status:** Tested  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Execution
Technique ID: T1059.001
Technique Name: PowerShell
Status: Tested
--> 
