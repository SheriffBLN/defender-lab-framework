# Alert: Internal Defacement

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1491.001  
**Nazwa:** Internal Defacement  
**Taktyki:** Impact  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Impact
Technique ID: T1491.001
Technique Name: Internal Defacement
Status: Pending
--> 
