# Alert: Windows Command Shell

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1059.003  
**Nazwa:** Windows Command Shell  
**Taktyki:** Execution  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Execution
Technique ID: T1059.003
Technique Name: Windows Command Shell
Status: Pending
--> 
