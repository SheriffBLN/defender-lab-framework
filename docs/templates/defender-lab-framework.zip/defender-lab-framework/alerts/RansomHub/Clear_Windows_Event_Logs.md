# Alert: Clear Windows Event Logs

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1070.001  
**Nazwa:** Clear Windows Event Logs  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1070.001
Technique Name: Clear Windows Event Logs
Status: Pending
--> 
