# Alert: Inhibit System Recovery

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1490  
**Nazwa:** Inhibit System Recovery  
**Taktyki:** Impact  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Impact
Technique ID: T1490
Technique Name: Inhibit System Recovery
Status: Pending
--> 
