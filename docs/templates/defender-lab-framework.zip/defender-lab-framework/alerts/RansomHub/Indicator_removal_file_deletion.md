# Alert: File Deletion

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1070.004  
**Nazwa:** File Deletion  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1070.004
Technique Name: File Deletion
Status: Pending
--> 
