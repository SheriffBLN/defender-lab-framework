# Alert: Time Based Evasion

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1497.003  
**Nazwa:** Time Based Evasion  
**Taktyki:** Defense-Evasion, Discovery  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion, Discovery
Technique ID: T1497.003
Technique Name: Time Based Evasion
Status: Pending
--> 
