# Alert: SMB/Windows Admin Shares

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1021.002  
**Nazwa:** SMB/Windows Admin Shares  
**Taktyki:** Lateral-Movement  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Lateral-Movement
Technique ID: T1021.002
Technique Name: SMB/Windows Admin Shares
Status: Pending
--> 
