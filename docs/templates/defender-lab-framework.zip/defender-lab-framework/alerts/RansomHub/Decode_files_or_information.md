# Alert: Deobfuscate/Decode Files or Information

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1140  
**Nazwa:** Deobfuscate/Decode Files or Information  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1140
Technique Name: Deobfuscate/Decode Files or Information
Status: Pending
--> 
