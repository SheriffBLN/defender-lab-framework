# Alert: File and Directory Discovery

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1083  
**Nazwa:** File and Directory Discovery  
**Taktyki:** Discovery  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Discovery
Technique ID: T1083
Technique Name: File and Directory Discovery
Status: Pending
--> 
