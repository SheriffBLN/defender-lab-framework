# Alert: Process Discovery

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1057  
**Nazwa:** Process Discovery  
**Taktyki:** Discovery  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Discovery
Technique ID: T1057
Technique Name: Process Discovery
Status: Pending
--> 
