# Alert: Safe Mode Boot

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1562.009  
**Nazwa:** Safe Mode Boot  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1562.009
Technique Name: Safe Mode Boot
Status: Pending
--> 
