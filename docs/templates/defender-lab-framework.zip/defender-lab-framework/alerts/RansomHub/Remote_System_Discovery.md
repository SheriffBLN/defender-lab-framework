# Alert: Remote System Discovery

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1018  
**Nazwa:** Remote System Discovery  
**Taktyki:** Discovery  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Discovery
Technique ID: T1018
Technique Name: Remote System Discovery
Status: Pending
--> 
