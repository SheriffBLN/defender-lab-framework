# Alert: PowerShell

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1059.001  
**Nazwa:** PowerShell  
**Taktyki:** Execution  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Execution
Technique ID: T1059.001
Technique Name: PowerShell
Status: Pending
--> 
