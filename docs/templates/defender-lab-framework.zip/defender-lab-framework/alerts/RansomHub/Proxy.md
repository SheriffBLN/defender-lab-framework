# Alert: Proxy

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1090  
**Nazwa:** Proxy  
**Taktyki:** Command-And-Control  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Command-And-Control
Technique ID: T1090
Technique Name: Proxy
Status: Pending
--> 
