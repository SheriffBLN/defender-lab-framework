# Alert: Service Stop

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1489  
**Nazwa:** Service Stop  
**Taktyki:** Impact  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Impact
Technique ID: T1489
Technique Name: Service Stop
Status: Pending
--> 
