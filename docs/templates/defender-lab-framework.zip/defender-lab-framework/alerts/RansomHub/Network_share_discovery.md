# Alert: Network Share Discovery

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1135  
**Nazwa:** Network Share Discovery  
**Taktyki:** Discovery  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Discovery
Technique ID: T1135
Technique Name: Network Share Discovery
Status: Pending
--> 
