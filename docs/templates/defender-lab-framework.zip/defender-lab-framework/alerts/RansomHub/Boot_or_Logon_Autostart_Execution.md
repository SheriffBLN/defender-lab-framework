# Alert: Registry Run Keys / Startup Folder

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1547.001  
**Nazwa:** Registry Run Keys / Startup Folder  
**Taktyki:** Persistence, Privilege-Escalation  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Persistence, Privilege-Escalation
Technique ID: T1547.001
Technique Name: Registry Run Keys / Startup Folder
Status: Pending
--> 
