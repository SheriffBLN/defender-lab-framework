# Alert: System Information Discovery

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1082  
**Nazwa:** System Information Discovery  
**Taktyki:** Discovery  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Discovery
Technique ID: T1082
Technique Name: System Information Discovery
Status: Pending
--> 
