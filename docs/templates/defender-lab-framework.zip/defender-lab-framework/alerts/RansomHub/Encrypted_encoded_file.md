# Alert: Encrypted/Encoded File

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1027.013  
**Nazwa:** Encrypted/Encoded File  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1027.013
Technique Name: Encrypted/Encoded File
Status: Pending
--> 
