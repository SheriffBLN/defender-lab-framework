# Alert: Execution Guardrails

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1480  
**Nazwa:** Execution Guardrails  
**Taktyki:** Defense-Evasion  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Defense-Evasion
Technique ID: T1480
Technique Name: Execution Guardrails
Status: Pending
--> 
