# Alert: Data Encrypted for Impact

Opis scenariusza, podatności lub techniki.

---

**Technika:** T1486  
**Nazwa:** Data Encrypted for Impact  
**Taktyki:** Impact  
**Status:** Pending  
**Autor:** Krzysztof K.  

---

<!--
Tactics: Impact
Technique ID: T1486
Technique Name: Data Encrypted for Impact
Status: Pending
--> 
