# 🔄 Instrukcja Update

1. Otwórz plik `/mapping/NAZWA/status.csv`
2. Edytuj status (Tested, Audit, Pending) lub inne pola, jeśli chcesz
3. Uruchom framework w trybie **Update**
4. Raport oraz macierz zostaną zaktualizowane na podstawie nowych statusów

Pamiętaj, żeby nie zmieniać ścieżek/folderów – framework mapuje dane na podstawie struktury katalogów.
