# Scenariusz testowy – T1480

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1480 – Execution Guardrails.

## Detekcja

Oczekiwany alert: `alerts\APT-test\alert.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Defense-Evasion.

**Status testu:** Pending
**Autor:** Krzysztof K.
