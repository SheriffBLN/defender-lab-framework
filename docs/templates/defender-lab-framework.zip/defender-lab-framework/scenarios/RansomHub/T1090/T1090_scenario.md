# Scenariusz testowy – T1090

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1090 – Proxy.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Proxy.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Command-And-Control.

**Status testu:** Pending
**Autor:** Krzysztof K.
