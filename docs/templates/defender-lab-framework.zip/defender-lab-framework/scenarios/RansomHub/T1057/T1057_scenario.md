# Scenariusz testowy – T1057

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1057 – Process Discovery.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Process_Discovery.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Discovery.

**Status testu:** Pending
**Autor:** Krzysztof K.
