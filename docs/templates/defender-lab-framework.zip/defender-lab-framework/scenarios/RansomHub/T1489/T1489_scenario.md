# Scenariusz testowy – T1489

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1489 – Service Stop.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Service_stop.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Impact.

**Status testu:** Pending
**Autor:** Krzysztof K.
