# Scenariusz testowy – T1135

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1135 – Network Share Discovery.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Network_share_discovery.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Discovery.

**Status testu:** Pending
**Autor:** Krzysztof K.
