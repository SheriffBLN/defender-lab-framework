# Scenariusz testowy – T1490

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1490 – Inhibit System Recovery.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Inhibit_system_recovery.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Impact.

**Status testu:** Pending
**Autor:** Krzysztof K.
