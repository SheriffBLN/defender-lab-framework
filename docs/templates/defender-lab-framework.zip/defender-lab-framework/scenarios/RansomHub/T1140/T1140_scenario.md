# Scenariusz testowy – T1140

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1140 – Deobfuscate/Decode Files or Information.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Decode_files_or_information.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Defense-Evasion.

**Status testu:** Pending
**Autor:** Krzysztof K.
