# Scenariusz testowy – T1083

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1083 – File and Directory Discovery.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\File_and_Directory_Discovery.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Discovery.

**Status testu:** Pending
**Autor:** Krzysztof K.
