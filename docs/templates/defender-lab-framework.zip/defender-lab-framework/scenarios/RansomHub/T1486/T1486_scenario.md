# Scenariusz testowy – T1486

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1486 – Data Encrypted for Impact.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\Data_encrypted_for_Impact.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Impact.

**Status testu:** Pending
**Autor:** Krzysztof K.
