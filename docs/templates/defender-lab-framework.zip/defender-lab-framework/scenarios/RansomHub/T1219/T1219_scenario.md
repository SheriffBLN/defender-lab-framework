# Scenariusz testowy – T1219

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1219 – Remote Access Tools.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\T1219_Remote_Access_Sofware_detection.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Command-And-Control.

**Status testu:** Tested
**Autor:** Krzysztof Krzymowski
