# Scenariusz testowy – T1082

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1082 – System Information Discovery.

## Detekcja

Oczekiwany alert: `alerts\RansomHub\System_information_discovery.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Discovery.

**Status testu:** Pending
**Autor:** Krzysztof K.
