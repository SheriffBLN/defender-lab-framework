# Alert: {technique_name}

## Opis

Opis scenariusza, podatności lub techniki.

---

**Technika:** {technique_id}  
**Nazwa:** {technique_name}  
**Taktyki:** {tactics}  
**Status:** {status}  
**Autor:** {author}  

---

## KQL – hunting query

```kql
{kql_queries}

<!--
Tactics: {tactics}
Technique ID: {technique_id}
Technique Name: {technique_name}
Status: {status}
-->
