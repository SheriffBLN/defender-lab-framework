# Detection notes for T1098.003 (Account Manipulation: Add Account to Group)

TODO