# Detection notes for T1136.002 (Create Account: Domain Account)

TODO