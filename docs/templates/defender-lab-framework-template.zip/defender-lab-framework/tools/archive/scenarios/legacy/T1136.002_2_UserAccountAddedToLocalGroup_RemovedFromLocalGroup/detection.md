# Detection notes for T1136.002 (LocalAccountGroupMembership)

TODO