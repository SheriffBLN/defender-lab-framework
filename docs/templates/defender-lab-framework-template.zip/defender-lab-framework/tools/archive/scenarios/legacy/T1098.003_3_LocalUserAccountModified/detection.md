# Detection notes for T1098.003 (LocalAccountManipulation)

TODO