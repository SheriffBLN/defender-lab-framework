## ❓ Najczęstsze pytania

**Jak dodać nowy scenariusz?**
> Uruchom `001_generate_by_tid.py`

**Czemu technika się nie pojawia?**
> Sprawdź czy w `.md` jest poprawna stopka `<!-- Tactics: ..., Status: ... -->`

**Gdzie znajdę plik `layer.json`?**
> W `mapping/mitre-navigator/layer.json`