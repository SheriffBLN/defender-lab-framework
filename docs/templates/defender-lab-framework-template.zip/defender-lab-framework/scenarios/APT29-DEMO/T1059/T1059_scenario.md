# Scenariusz testowy – T1059

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1059 – Command and Scripting Interpreter.

## Detekcja

Oczekiwany alert: `alerts\APT29-DEMO\alert.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Execution.

**Status testu:** Pending
**Autor:** Krzysztof Krzymowski
