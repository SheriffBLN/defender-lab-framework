# Scenariusz testowy – T1650

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1650 – Acquire Access.

## Detekcja

Oczekiwany alert: `alerts\APT29-DEMO\alert.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Resource-Development.

**Status testu:** Audit
**Autor:** Rafał Demontracyjny
