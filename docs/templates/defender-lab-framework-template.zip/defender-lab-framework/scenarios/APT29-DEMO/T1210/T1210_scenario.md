# Scenariusz testowy – T1210

## Symulacja ataku

Opis: Tutaj wpisz jak zasymulować technikę T1210 – Exploitation of Remote Services.

## Detekcja

Oczekiwany alert: `alerts\APT29-DEMO\alert.md`

## Oczekiwany efekt

Technika powinna zostać wykryta w systemie M365 Defender. Taktyki: Lateral-Movement.

**Status testu:** Pending
**Autor:** Krzysztof Krzymowski
