# Alert: Exploitation of Remote Services

Opis scenariusza lub detekcji.

<!--
Tactics: Lateral-Movement
Technique ID: T1210
Technique Name: Exploitation of Remote Services
Status: Audit
-->
