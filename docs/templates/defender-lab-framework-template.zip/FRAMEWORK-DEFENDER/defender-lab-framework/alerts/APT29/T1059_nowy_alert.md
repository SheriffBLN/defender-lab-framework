# Alert: Command and Scripting Interpreter

Opis scenariusza lub detekcji.

<!--
Tactics: Execution
Technique ID: T1059
Technique Name: Command and Scripting Interpreter
Status: Pending
-->
