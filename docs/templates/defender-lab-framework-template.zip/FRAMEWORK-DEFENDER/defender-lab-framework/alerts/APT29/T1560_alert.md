# Alert: Archive Collected Data

Opis scenariusza lub detekcji.

<!--
Tactics: Collection
Technique ID: T1560
Technique Name: Archive Collected Data
Status: Tested
-->
